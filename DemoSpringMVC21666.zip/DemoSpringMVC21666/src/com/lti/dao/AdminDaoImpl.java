package com.lti.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.lti.model.Customer;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.sun.media.jfxmedia.logging.Logger;



public class AdminDaoImpl implements IAdminDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	
	
	@Override
	public List<Customer> listAllCustomer() {
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		String query="from Customer";
		Query q=session.createQuery(query);
		List<Customer> customerList=q.list();
		tx.commit();
		session.close();
		return customerList;
	}

	@Override
	public void acceptCustomer(String emailId) {
		
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		String query="update LoanDetails l set l.requestStatus='ACCEPTED' where p.cropId=:cropId";
		Query q=session.createQuery(query);
		q.setInteger("cropId", id);
		q.executeUpdate();
		
		tx.commit();
		session.close();
		
		
	}

	@Override
	public void rejectCustomer(String emailId) {
		// TODO Auto-generated method stub

	}

}
