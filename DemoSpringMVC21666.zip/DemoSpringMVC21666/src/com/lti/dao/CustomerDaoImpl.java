package com.lti.dao;

import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.Customer;


@Transactional
@Repository
public class CustomerDaoImpl implements ICustomerDao {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	
	
	
	
	@Override
	public void addCustomer(Customer customer) {
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(customer);
		
		tx.commit();
		session.close();
		
	}
	
	@Override
	public boolean verifyUser(String emailId, String password) {
		Session session = this.sessionFactory.openSession();
		 

		  String query="select emailId, password from Customer a where a.emailId=:emailId and a.password=:password";
		  
		  Query q=session.createQuery(query);
		  q.setString("emailId", emailId);
		  q.setString("password", password);
		  List<Customer> l=q.list();
		  
if(l.size()==0)
{
	  return false;
}
session.close();
	  return true;

	}
	
	
	@Override
	public Customer getCustomer(String emailId, String password) {
		Customer c1 = new Customer();
		Session session = this.sessionFactory.openSession();
		String query = "from Customer a where a.emailId=:emailId and a.password=:password";
		
		Query q = session.createQuery(query);
		 q.setString("emailId", emailId);
		
		 q.setString("password", password);
		 
		 System.out.println("1");
		 List<Customer> l=q.list();

		 System.out.println("2");
		if (l.size() == 0) {
			return null;
		}
		
		Iterator iterator =  l.iterator();
		while (iterator.hasNext())
		{
			System.out.println("3");
	        c1 = (Customer)iterator.next();
			
		}
		
		System.out.println("c1 obj"+c1);
		session.close();
		System.out.println("returnning ..");
		return c1;
	}
}

	
	


