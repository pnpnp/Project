package com.lti.dao;

import java.util.List;

import com.lti.model.Customer;

public interface IAdminDao {

	
	public List<Customer> listAllCustomer(); 
	
	public void acceptCustomer(String emailId);
	
	public void rejectCustomer(String emailId);
	
}
