package com.projhibernate.HibernateAnnotation;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="LoanDetails")
public class LoanDetails {


public LoanDetails() {
		super();
	}
public LoanDetails(float maxamountGrantable, float interestRate, int tenure, float loanAmount, int loanId,
			String status) {
		super();
		MaxamountGrantable = maxamountGrantable;
		InterestRate = interestRate;
		Tenure = tenure;
		LoanAmount = loanAmount;
		LoanId = loanId;
		Status = status;
	}

@Column(name="MaxamountGrantable")
private float MaxamountGrantable;
@Column(name="InterestRate")
private float InterestRate;
@Column(name="Tenure")
private int Tenure;
@Column(name="LoanAmount")
private float LoanAmount;
@Column(name="LoanId")
private int LoanId;
@Column(name="Status")
 private String Status;
 
 public float getMaxamountGrantable() {
		return MaxamountGrantable;
	}
	public float getInterestRate() {
		return InterestRate;
	}
	public int getTenure() {
		return Tenure;
	}
	public float getLoanAmount() {
		return LoanAmount;
	}
	public int getLoanId() {
		return LoanId;
	}
	public String getStatus() {
		return Status;
	}
	public void setMaxamountGrantable(float maxamountGrantable) {
		MaxamountGrantable = maxamountGrantable;
	}
	public void setInterestRate(float interestRate) {
		InterestRate = interestRate;
	}
	public void setTenure(int tenure) {
		Tenure = tenure;
	}
	public void setLoanAmount(float loanAmount) {
		LoanAmount = loanAmount;
	}
	public void setLoanId(int loanId) {
		LoanId = loanId;
	}
	public void setStatus(String status) {
		Status = status;
	}
		@Override
		public String toString() {
			return "LoanDetails [MaxamountGrantable=" + MaxamountGrantable + ", InterestRate=" + InterestRate + ", Tenure="
					+ Tenure + ", LoanAmount=" + LoanAmount + ", LoanId=" + LoanId + ", Status=" + Status + "]";
		}
		
	
}
