package com.lti.mvc.dao;

import java.util.List;

import com.lti.mvc.model.Department;

public interface IDepartmentDAO {
	public void createDept(Department d);

	public void deleteDept(int id);

	public List<Department> listDept();

	public Department listById(int id);
}
