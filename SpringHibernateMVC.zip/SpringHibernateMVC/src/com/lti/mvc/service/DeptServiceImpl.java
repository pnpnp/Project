package com.lti.mvc.service;

import java.util.List;

import com.lti.mvc.dao.IDepartmentDAO;
import com.lti.mvc.model.Department;

public class DeptServiceImpl implements IDeptService {
	private IDepartmentDAO deptdao;

	@Override
	public void createDept(Department d) {
		// TODO Auto-generated method stub
		this.deptdao.createDept(d);
	}

	@Override
	public void deleteDept(int id) {
		// TODO Auto-generated method stub
		this.deptdao.deleteDept(id);
	}

	@Override
	public List<Department> listDept() {
		// TODO Auto-generated method stub
		return this.deptdao.listDept();
	}

	@Override
	public Department listById(int id) {
		// TODO Auto-generated method stub
		return this.deptdao.listById(id);
	}

}
