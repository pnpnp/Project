package com.lti.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.model.Customer;

@Service
public interface AdminService {
	
	
	
	public List<Customer> custlist();
	
	public void acceptCust(String emailId);
	
	public void rejectCust(String emailId);
	
}
