package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.ICustomerDao;
import com.lti.model.Customer;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Override
	public List<Customer> custlist() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean verifyUser(String emailId, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(String emailId, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	
	