package com.lti.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.IAdminDao;
import com.lti.model.Customer;



@Service
@Transactional
public class IAdminServiceImpl implements AdminService{
	
	@Autowired
	private IAdminDao iAdminDao;

	@Override
	public List<Customer> custlist() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void acceptCust(String emailId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rejectCust(String emailId) {
		// TODO Auto-generated method stub
		
	}
	

}
