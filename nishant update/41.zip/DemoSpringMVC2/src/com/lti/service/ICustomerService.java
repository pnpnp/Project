package com.lti.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.model.Customer;

@Service
public interface ICustomerService {
	
	
	public List<Customer> custlist();
	public void addCustomer(Customer customer);
	
	
	public boolean verifyUser(String emailId, String password);
	
	
	public Customer getCustomer(String emailId, String password);
	

	
	
}
